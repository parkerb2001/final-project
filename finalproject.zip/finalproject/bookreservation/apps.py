from django.apps import AppConfig


class BookreservationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookreservation'
